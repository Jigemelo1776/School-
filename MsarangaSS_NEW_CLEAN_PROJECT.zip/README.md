# Msaranga SS Android App

App name: Msaranga SS
School: Msaranga Secondary School
Website: https://msarangaresults.netlify.app/
Package: com.msaranga.ss

This app is a lightweight Android WebView wrapper around the existing Msaranga Results website.
It uses only the Android SDK and has no AndroidX dependencies.

Build:
gradle :app:assembleDebug

APK:
app/build/outputs/apk/debug/app-debug.apk
