# Msaranga SS Android App

This is an Android WebView wrapper for:
https://msarangaresults.netlify.app/

App name: Msaranga SS
Package: com.msaranga.ss

Build:
1. Open this folder in Android Studio.
2. Let Gradle sync.
3. Build > Build APK(s).
4. Install the generated APK on Android.

The app keeps the existing Netlify/Apps Script backend. It does not copy or replace your school data.
